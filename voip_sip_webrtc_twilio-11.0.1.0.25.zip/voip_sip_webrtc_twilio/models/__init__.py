# -*- coding: utf-8 -*-

from . import voip_twilio
from . import voip_call
from . import voip_call_wizard
from . import res_partner
from . import voip_number
from . import voip_account_action
from . import crm_lead
from . import mail_activity