v1.1.4
======
* Fix to work in latest version of Google Chrome

v1.1.3
======
* No presence bug fix

v1.1.2
======
* RTP data is now saved if call recording setting is ticked
* Presence recode to improve accuracy (hopefully...)
* New presence light

v1.1.1
======
* Find local outgoing IP address button to make SIP setup a little easier

v1.1.0
======
* Call dialogs and DTMF call action

v1.0.6
======
* Compact call menu

v1.0.5
======
* Adjust permissions

v1.0.4
======
* Setting to adjust presence detection

v1.0.3
======
* Remove broken SIP widget

v1.0.2
======
* Convert sip_register, sip_invite and rtp code to python 3

v1.0.1
======
* Unhide voip account field in user form view

v1.0
====
* Port to v11