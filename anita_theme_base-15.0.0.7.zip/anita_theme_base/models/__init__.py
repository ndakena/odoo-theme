# -*- coding: utf-8 -*-

from . import anita_view_extend
